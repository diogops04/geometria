package back.dado;

public interface InterfaceGeometria {
	
	public double getArea();
	public double getPerimetro();
	public String getCor();
	public void setCor(String c);

}